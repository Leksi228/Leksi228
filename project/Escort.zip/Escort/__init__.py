"""Telegram bots (escort + support).

Run:
  python escort_bot.py
  python support_bot.py
"""
