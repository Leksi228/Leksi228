"""Escort bot package."""
